"""
Modul EDA.
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(style='darkgrid')


def load_data(path):
    """Returns a pandas DataFrame for the CSV found at path

    Args:
        path (str): a path to the CSV file

    Returns:
        pandas DataFrame
    """
    return pd.read_csv(path)


def perform_eda(dataframe):
    """Perform EDA on data_frame and save figures to images folder

    Args:
        dataframe (DataFrame): pandas DataFrame

    Returns:
        eda_df : pandas DataFrame
    """
    eda_df = dataframe.copy(deep=True)

    # Memastikan direktori 'images' ada
    if not os.path.exists('images'):
        os.makedirs('images')

    # Visualisasi distribusi label
    label_counts = eda_df['recommended_ind'].value_counts()
    plt.figure(figsize=(7, 7))
    sns.barplot(x=label_counts.index,
                y=label_counts.values,
                hue=label_counts.index,
                palette='viridis',
                dodge=False,
                legend=False)
    plt.title('Distribusi Label', fontsize=18)
    plt.xlabel('Label', fontsize=14)
    plt.ylabel('Count', fontsize=14)
    plt.savefig('images/recommended_distribution.png')
    plt.close()

    # Menampilkan contoh review untuk setiap label
    for label in eda_df['recommended_ind'].unique():
        print(f"\nContoh review untuk label {label}:")
        print(eda_df[eda_df['recommended_ind'] == label]
              ['review_text'].iloc[0])

    return eda_df


if __name__ == '__main__':
    clothing_df = load_data(path='./data/data.csv')

    eda = perform_eda(dataframe=clothing_df)
